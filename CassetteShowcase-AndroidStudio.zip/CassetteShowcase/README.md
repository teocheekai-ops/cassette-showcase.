# Cassette Showcase (Android)

A minimal full-screen cassette display. The original Sony Metallic 46 artwork is included with blue and red recolored variants. Both tape reels rotate continuously; tap one of the three dots at the bottom to change color. Tap the left or right half of the screen to cycle variants as well.

## Build an APK from an Android phone (GitHub Actions)

1. Create a free GitHub account at https://github.com/ if you do not already have one.
2. In Chrome, create a **new public repository** named `cassette-showcase`.
3. In the repository, choose **Add file → Create new file**. Name it `.github/workflows/android.yml`.
4. Paste the workflow from the `.github/workflows/android.yml` file in this project (also provided separately in the project ZIP), then commit the file to the `main` branch.
5. Back in the repository, choose **Add file → Upload files** and upload the original project ZIP named `CassetteShowcase-AndroidStudio.zip` to the repository's top level. Commit the upload to `main`.
6. Open the repository's **Actions** tab. Select **Build Android APK**. If it has not started automatically, choose **Run workflow → Run workflow**.
7. Wait for the run to finish with a green check. Open the completed run, scroll to **Artifacts**, and download `CassetteShowcase-debug-apk`.
8. The downloaded artifact is another ZIP. Open it in the Android Files app and extract `app-debug.apk`.
9. Tap `app-debug.apk` and allow Chrome or Files to **Install unknown apps** if Android asks. Then install and open Cassette Showcase.

The workflow uses GitHub-hosted runners; no Android build tools are installed on your phone. The APK is a debug build for personal installation, not a Play Store release.

## Local build (computer)

Open this folder in Android Studio, allow Gradle sync, then select **Build → Build Bundle(s) / APK(s) → Build APK(s)**. The APK is at `app/build/outputs/apk/debug/app-debug.apk`.

The project uses Kotlin and a custom Canvas view. No network permission or account is required by the app. The app is immersive full-screen and keeps the display awake while open.
