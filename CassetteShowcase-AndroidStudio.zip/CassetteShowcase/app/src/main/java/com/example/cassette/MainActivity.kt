package com.example.cassette

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.graphics.*
import android.content.Context
import android.view.MotionEvent
import android.os.SystemClock
import kotlin.math.min

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(CassetteView(this))
    }
}

private class CassetteView(context: Context) : View(context) {
    private val variants = arrayOf("black", "blue", "red")
    private val labels = arrayOf("BLACK", "BLUE", "RED")
    private var selected = 0
    private val tapes = variants.map { BitmapFactory.decodeStream(context.assets.open("cassette_$it.jpg")) }
    private val reels = listOf(
        BitmapFactory.decodeStream(context.assets.open("reel_1.png")),
        BitmapFactory.decodeStream(context.assets.open("reel_2.png"))
    )
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(150,150,150); textSize = 24f; textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); letterSpacingCompat() }
    private var start = SystemClock.uptimeMillis()
    private var scale = 1f
    private var left = 0f
    private var top = 0f
    private var tapeW = 0f
    private var tapeH = 0f
    private var reelSize = 0f
    private var centerY = 0f

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.BLACK)
        val bmp = tapes[selected]
        scale = min(width.toFloat() / bmp.width, height.toFloat() * 0.56f / bmp.height)
        tapeW = bmp.width * scale
        tapeH = bmp.height * scale
        left = (width - tapeW) / 2f
        top = (height - tapeH) / 2f - height * 0.015f
        centerY = top + 355f * scale
        reelSize = 164f * scale
        canvas.drawBitmap(bmp, null, RectF(left, top, left + tapeW, top + tapeH), paint)
        val angle = ((SystemClock.uptimeMillis() - start) * 0.18f) % 360f
        val centers = floatArrayOf(500f, 1040f)
        for (i in 0..1) {
            val cx = left + centers[i] * scale
            val cy = centerY
            val save = canvas.save()
            canvas.rotate(angle, cx, cy)
            val half = reelSize / 2f
            canvas.drawBitmap(reels[i], null, RectF(cx-half, cy-half, cx+half, cy+half), paint)
            canvas.restoreToCount(save)
        }
        // Small, unobtrusive color selector
        val dotY = height * 0.91f
        val spacing = 62f
        for (i in 0..2) {
            dotPaint.color = when (i) { 0 -> Color.rgb(190,185,170); 1 -> Color.rgb(65,130,220); else -> Color.rgb(205,65,55) }
            dotPaint.style = Paint.Style.FILL
            canvas.drawCircle(width/2f + (i-1)*spacing, dotY, if (i == selected) 12f else 9f, dotPaint)
            if (i == selected) {
                dotPaint.color = Color.WHITE
                dotPaint.style = Paint.Style.STROKE
                dotPaint.strokeWidth = 2f
                canvas.drawCircle(width/2f + (i-1)*spacing, dotY, 17f, dotPaint)
            }
        }
        dotPaint.style = Paint.Style.FILL
        postInvalidateOnAnimation()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP) {
            val y = height * 0.91f
            if (event.y > y - 55f) {
                val index = ((event.x - width/2f) / 62f).toInt() + 1
                if (index in 0..2) { selected = index; invalidate() }
            } else if (event.x < width/2f) {
                selected = (selected + 2) % 3; invalidate()
            } else {
                selected = (selected + 1) % 3; invalidate()
            }
            return true
        }
        return true
    }
}

private fun Paint.letterSpacingCompat() { /* platform-safe placeholder */ }
